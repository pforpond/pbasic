bird.png - http://mavencube.com/lab/Game/images/sprite-image/bird-sprite.png
blood.png - https://opengameart.org/sites/default/files/blood.png
crow.png - https://s3.amazonaws.com/quizzpot/images/205-crow.png
eagle.png - https://orig00.deviantart.net/b051/f/2014/036/d/0/rpg_maker_vx___xp_to_vx_bald_eagle_by_qtpi_0121-d759qqf.png
explosion.png - http://hasgraphics.com/wp-content/uploads/2010/08/spritesheet1.png
farm_night.jpg - https://us.123rf.com/450wm/alexmstudio/alexmstudio1407/alexmstudio140700043/30176412-night-landscape-farm-with-a-house-cartoon-illustration.jpg?ver=8
farm_night_2.jpg - https://cdn3.vectorstock.com/i/1000x1000/07/02/night-farm-landscape-vector-5160702.jpg
farm1.jpeg - http://thumb9.shutterstock.com/display_pic_with_logo/633364/633364,1330508836,2/stock-vector-rural-landscape-with-fields-and-hills-96359360.jpg [Edited By Me.]
farm3.jpg - https://thumbs.dreamstime.com/z/dandelion-field-10873305.jpg
farm4.jpg - https://img.myloview.fr/images/un-champ-de-ble-400-71841.jpg
Gun_ak-37.png : https://openclipart.org/download/216518/1427590480.svg
gun_shot.png : http://clipart-library.com/image_gallery/496791.png
jet.png, jet_2.png, jet_3.png : IDK
loader.png : http://v3.preloaders.net/en/circular
shoot.jpg : http://clipart-library.com/data_images/467534.jpg
dark_clouds.jpg : https://pixabay.com/en/dark-clouds-clouds-after-the-storm-228883/

Rest all the images file in this directory is created/edited by Ashish in MS Paint and Adobe Photoshop CC 2017